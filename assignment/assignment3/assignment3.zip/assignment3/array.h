// name: 임형근
// student ID: 20201261
// description: contatins prototypes of mean and maximum_value function

#ifndef ARRAY_H
#define ARRAY_H

#include <cstddef> // for a definition of size_t

double mean(double const *, size_t);

double *maximum_value(double *, size_t);

#endif
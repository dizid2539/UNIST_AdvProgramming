// name: 임형근
// student ID: 20201261
// description: contains prototypes of factorial and probability function

double factorial(int x);
double probability(int k, int n);